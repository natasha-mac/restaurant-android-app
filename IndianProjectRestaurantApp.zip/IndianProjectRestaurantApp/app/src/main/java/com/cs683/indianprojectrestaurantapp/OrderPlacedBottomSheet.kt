package com.cs683.indianprojectrestaurantapp

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.cs683.indianprojectrestaurantapp.databinding.FragmentOrderPlacedBottomSheetBinding
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class OrderPlacedBottomSheet : BottomSheetDialogFragment() {
    private lateinit var binding :FragmentOrderPlacedBottomSheetBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentOrderPlacedBottomSheetBinding.inflate(layoutInflater,container,false)
        binding.goHomeButton.setOnClickListener {
            val intent = Intent(requireContext(), MainActivity::class.java)
            startActivity(intent)
        }
        return binding.root
    }

    companion object {

    }
}